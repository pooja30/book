/**
 * Package showing usage of Spring Data LDAP Repositories.
 */
package example.springdata.ldap;
