# Spring Data Elasticsearch - Examples

Requirements:

 * [Maven](http://maven.apache.org/download.cgi) - required.
 * [Elasticsearch](http://www.elasticsearch.org/overview/elkdownloads) - optional.


To use local elasticsearch cluster:

* install elasticsearch 
* uncomment both properties in file 'application.properties'
 
 