/**
 * Sample showing JPA 2.1 related features of Spring Data JPA.
 *
 * @author Thomas Darimont
 * @author Oliver Gierke
 */
package example.springdata.jpa.storedprocedures;