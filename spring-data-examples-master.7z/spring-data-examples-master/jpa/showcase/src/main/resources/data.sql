INSERT INTO Customer (id, firstname, lastname) VALUES (1, 'Dave', 'Matthews');
INSERT INTO Customer (id, firstname, lastname) VALUES (2, 'Carter', 'Beauford');
INSERT INTO Customer (id, firstname, lastname) VALUES (3, 'Stephan', 'Lassard');

INSERT INTO Account (id, customer_id, expiry_date) VALUES (1, 1, '2010-12-31');
INSERT INTO Account (id, customer_id, expiry_date) VALUES (2, 1, '2011-03-31');

INSERT INTO Customer (id, firstname, lastname) VALUES (4, 'Charly', 'Matthews');
INSERT INTO Customer (id, firstname, lastname) VALUES (5, 'Chris', 'Matthews');
INSERT INTO Customer (id, firstname, lastname) VALUES (6, 'Paula', 'Matthews');