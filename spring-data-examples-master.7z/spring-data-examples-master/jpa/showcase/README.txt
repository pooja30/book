Spring Data JPA showcase
------------------------

This is the sample app to demo Spring Data JPA features at conferences. The two main packages to take a look at are example.springdata.jpa.showcase.before and example.springdata.jpa.showcase.after. The first one shows a typical data access implementation with JPA 2. The second one shows what's left if you use Spring Data JPA.