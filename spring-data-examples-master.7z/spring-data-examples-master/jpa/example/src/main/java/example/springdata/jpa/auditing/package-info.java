/**
 * Package showing auditing support with Spring Data repositories.
 */
package example.springdata.jpa.auditing;