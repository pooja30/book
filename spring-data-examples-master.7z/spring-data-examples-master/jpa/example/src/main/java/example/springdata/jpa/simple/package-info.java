/**
 * Package showing a simple repository interface to use basic query method execution functionality.
 */
package example.springdata.jpa.simple;

