/**
 * Sample for the integration of the Spring caching abstraction with Spring Data repositories.
 */
package example.springdata.jpa.caching;

