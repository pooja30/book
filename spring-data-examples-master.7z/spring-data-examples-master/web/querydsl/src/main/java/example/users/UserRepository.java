package example.users;

import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.querydsl.binding.QuerydslBinderCustomizer;
import org.springframework.data.querydsl.binding.QuerydslBindings;
import org.springframework.data.repository.CrudRepository;

import com.querydsl.core.types.dsl.StringPath;

import example.users.QUser;
import example.users.User;

/**
 * Repository to manage {@link User}s. Also implements {@link QueryDslPredicateExecutor} to enable predicate filtering
 * on Spring MVC controllers as well as {@link QuerydslBinderCustomizer} to tweak the way predicates are created for
 * properties.
 *
 * @author Christoph Strobl
 * @author Oliver Gierke
 */
public interface UserRepository
		extends CrudRepository<User, String>, QuerydslPredicateExecutor<User>, QuerydslBinderCustomizer<QUser> {

	@Override
	default public void customize(QuerydslBindings bindings, QUser root) {

		bindings.bind(String.class).first((StringPath path, String value) -> path.containsIgnoreCase(value));
		bindings.excluding(root.password);
	}
}
