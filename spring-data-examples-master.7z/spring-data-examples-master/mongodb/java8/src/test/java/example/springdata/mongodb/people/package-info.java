/**
 * Package showing usage of Spring Data MongoDB Repositories with Java 8.
 */
package example.springdata.mongodb.people;

