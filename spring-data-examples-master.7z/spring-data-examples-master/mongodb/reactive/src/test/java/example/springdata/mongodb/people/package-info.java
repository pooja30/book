/**
 * Package showing usage of Spring Data MongoDB Reactive Repositories and reactive MongoDB template.
 */
package example.springdata.mongodb.people;
