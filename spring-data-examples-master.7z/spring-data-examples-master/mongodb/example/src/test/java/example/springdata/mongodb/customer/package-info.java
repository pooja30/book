/**
 * Package showing basic usage of Spring Data MongoDB Repositories.
 */
package example.springdata.mongodb.customer;

