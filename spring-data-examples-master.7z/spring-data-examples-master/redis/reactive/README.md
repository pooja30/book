# Spring Data Redis 2.0 - Reactive examples

This project contains samples of reactive data access features with Spring Data (Redis).

## Prerequisites

This project contains samples of specific features of Spring Data Redis using reactive infrastructure.

