# Spring Data Redis Example

The this example was named a bit misleading as `cluster-sentinel` is a mix of Redis Cluster and Redis Sentinel.

Find dedicated examples here: [Redis Cluster](../cluster) and [Redis Sentinel](../sentinel).
