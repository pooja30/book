package com.example.courseproject.courses;

import org.springframework.stereotype.Service;

@Service
public class CourseService {
	
	

}
