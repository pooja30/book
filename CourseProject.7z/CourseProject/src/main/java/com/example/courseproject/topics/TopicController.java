package com.example.courseproject.topics;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value="Topic controller Api", produces=MediaType.APPLICATION_JSON_VALUE)
public class TopicController {
	@Autowired
	private TopicService topicService;

	@GetMapping("/topics")
	@ApiOperation("Get all the topic available")
	@ApiResponses(value={@ApiResponse(code=200,message="OK",response=Topic.class)})
	public List<Topic> listOfTopics() {

		return topicService.getAllTopics();

	}

	@GetMapping("/topics/{id}") /////////////////// id is a variable
	@ApiOperation("Get the topic by id")
	@ApiResponses(value={@ApiResponse(code=200,message="OK",response=Topic.class)})
	public Topic getTopicDetails(@PathVariable String id) { ///// id is a
															///// variable of
															///// url
		return topicService.getTopicById(id);

	}

	@PostMapping("/topics/add")
	public void addTopic(@RequestBody Topic topic) {
		topicService.addNewTopic(topic);
	}
	
	/*@PutMapping("/topics/{id}")
	public void updateTopic(@RequestBody Topic topic,@PathVariable String id) {
		topicService.updateTopic(id, topic);
		
	}*/
	@PutMapping("/topics/{id}")
	public void updateTopic(@RequestBody Topic topic,@PathVariable String id) {
		topicService.updateTopic1(id,topic);
	}
	
	@DeleteMapping("/topics/{id}")
	public void deleteTopic(@PathVariable String id){
		 topicService.deleteTopic(id);
	}
	
	

}
