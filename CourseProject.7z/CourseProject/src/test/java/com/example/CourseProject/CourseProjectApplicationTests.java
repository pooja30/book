package com.example.CourseProject;

import static org.junit.Assert.*;

import java.io.UnsupportedEncodingException;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.courseproject.topics.Topic;
import com.example.courseproject.topics.TopicService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CourseProjectApplicationTests {
	@Test
	public void contextLoads() {
		
	}
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private TopicService topicService;

	
@Test
public void testAddTopic() throws Exception{

	Topic mokTopic =new Topic();
	mokTopic.setId("Spring1");
	mokTopic.setName("Spring Boot2");
	mokTopic.setDescription("Annotations");
	String inputJSON=this.mapToJson(mokTopic);
	
	String URI="/topics/add";
	//Mockito.when(topicService.addNewTopic(Mockito.any(Topic.class))).thenReturn(mokTopic);
	RequestBuilder requestBuilder=MockMvcRequestBuilders.post(URI)
			.content(inputJSON)
			.contentType(MediaType.APPLICATION_JSON);
	MvcResult result= mockMvc.perform(requestBuilder).andReturn();

	MockHttpServletResponse response=result.getResponse();
	String OutputJson;
	try {
		OutputJson = response.getContentAsString();
		assertTrue(OutputJson.equalsIgnoreCase(inputJSON));
		assertEquals(HttpStatus.OK.value(),response.getStatus());
			
	} catch (UnsupportedEncodingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try {
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	
}
private String mapToJson(Object obj) {
	ObjectMapper objectMapper=new ObjectMapper();
	try {
		System.out.println(objectMapper.writeValueAsString(obj));
		return objectMapper.writeValueAsString(obj);
	} catch (JsonProcessingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
}
}
