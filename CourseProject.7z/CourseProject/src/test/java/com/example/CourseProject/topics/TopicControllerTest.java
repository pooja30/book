package com.example.CourseProject.topics;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.courseproject.topics.Topic;
import com.example.courseproject.topics.TopicController;
import com.example.courseproject.topics.TopicService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@WebMvcTest(value = TopicController.class, secure = false)
public class TopicControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private TopicService topicService;

	 Topic mokTopic=new Topic("topic1","Spring","Annotation");

	
//	String exampleCourseJson = "{\"id\":\"Course1\",\"name\":\"Spring\",\"description\":\"10 Steps\"}";

	@Test
	public void testGetTopicDetails() throws Exception {

		Mockito.when(
				topicService.getTopicById(Mockito.anyString())).thenReturn(mokTopic);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/topics/topic1").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{id:topic1,name:Spring,description:Annotation}";

		// {"id":"Course1","name":"Spring","description":"10 Steps, 25 Examples and 10K Students","steps":["Learn Maven","Import Project","First Example","Second Example"]}

		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}
	/*private String mapToJson(Object obj) {
		ObjectMapper objectMapper=new ObjectMapper();
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}*/

}