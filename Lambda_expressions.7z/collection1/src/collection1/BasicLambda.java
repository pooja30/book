package collection1;

public class BasicLambda {

	public static void main(String[] args) {

		BasicLambda obj = new BasicLambda();
		MathOperation addition = (int a, int b) -> a + b;
		MathOperation subtraction = (a, b) -> a - b;
		MathOperation multiplication = (a, b) -> a * b;
		MathOperation division = (a, b) -> a / b;

		System.out.println(obj.operate(10, 5, addition));
		System.out.println(obj.operate(20, 14, subtraction));
		System.out.println(obj.operate(10, 5, multiplication));
		System.out.println(obj.operate(20, 14, division));

		Greeting greeting = (message) -> System.out.println("Hello" + message);
		greeting.greet("Pooja");

		Greeting1 greeting1 =  message -> ("Hello" + message);
		greeting1.greet("Ahana");
		System.out.println(greeting1);

	}

	interface Greeting {
		public void greet(String msg);

	}

	interface Greeting1 {
		public String greet(String msg);

	}

	interface MathOperation {
		public int operation(int a, int b);
	}

	public int operate(int a, int b, MathOperation mathopration) {
		return mathopration.operation(a, b);
	}

}
