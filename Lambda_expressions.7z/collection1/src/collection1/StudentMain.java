package collection1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StudentMain {

	public static void main(String[] args) {
		List<Student> student = Arrays.asList(new Student("Pooja", 23, 80), new Student("Ahana", 26, 70),
				new Student("Angel", 25, 90));
		////////////////////////// to get single value
		String name = student.parallelStream().filter(s1 -> "Pooja".equals(s1.getName()))
				.map(Student::getName) // convert stream to String
				.findAny().orElse(null);
		System.out.println(name);
		
		


		
		
		////////////////////////// to get object value
		Student name1 = student.parallelStream().filter(s1 -> "Pooja".equals(s1.getName()))
				//.map(Student::getName) // convert stream to String
				.findAny().orElse(null);
		System.out.println(name1);
		
		
		
		///////////////////////to print list of name of students
		System.out.println("**************************Parallel Stream************");
		List<String> nList=student.parallelStream()
				.map(Student::getName)
				.collect(Collectors.toList());
		nList.forEach(System.out::println);
		
		
		System.out.println("************************Stream*****************");
		List<String> nList1=student.parallelStream()
				.map(Student::getName)
				.collect(Collectors.toList());
		nList.forEach(System.out::println);
		
		/*//////////////////////map
		
		List<Student> s1=student.parallelStream().map(temp ->{
			NewStudent s2=new NewStudent();
			
		}
			
				)*/
		
		
		
	}

}
