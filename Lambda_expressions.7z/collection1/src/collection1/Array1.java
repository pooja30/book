package collection1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.IntSummaryStatistics;



public class Array1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List emp = new ArrayList<String>();
		for (int i = 0; i < 10; i++) {
			emp.add(i + "A");
		}

		///////////////////////// Traversing using forEach with Consumer
		emp.forEach(new Consumer<String>() {

			public void accept(String t) {
				System.out.println("Emplyee ID::" + t);
			}

		});

		//////////////////////// Traversing using forEach and lambda

		emp.forEach(em -> System.out.println(em));

		/////////////////////////////// Stream example

		List<String> list1 = Arrays.asList("Pooja", "Ahana", "angel");
		List<String> result1 = list1.stream().filter(list11 -> !"Ahana".equals(list11)).collect(Collectors.toList());

		result1.forEach(System.out::println);

		////////////////////// Parallel Streams

		List<Integer> list = new ArrayList<Integer>();
		for (int i = 1; i < 10; i++) {
			list.add(i);
		}
		// Here creating a parallel stream
		Stream<Integer> stream = list.parallelStream();
		List<Integer> evenNumbersArr = stream.filter(i -> i % 2 == 0).collect(Collectors.toList());
		System.out.println(evenNumbersArr);
		
		
		
		/////////////////////////////
		System.out.println("Random numbers");
		Random random = new Random();
		random.ints().limit(10).forEach(System.out::println);
		
		

		//get list of unique squares
		List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
		List<Integer> squaresList = numbers.stream().map( i -> i*i).distinct().sorted().collect(Collectors.toList());
		System.out.println(squaresList);
		
		
		

		//get count of empty string
		List<String>strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
		long count = strings.stream().filter(string -> string.isEmpty()).count();
		System.out.println(count);
		
		
		

	}

}
