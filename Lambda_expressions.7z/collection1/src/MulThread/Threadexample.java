package MulThread;

public class Threadexample extends Thread {
	private String msg;

	public Threadexample(String str) {
		msg = str;
	}
	@Override
	public void run() {
		for(int i=0;i<50;i++){
			System.out.println(msg+i);
		}
	}
	

	
	///////////////////////////////////Run method using lambda expression
	/*RunInterface run=()->{
		for(int i=0;i<50;i++){
			System.out.println(i);
		}
	};
	*/
	interface RunInterface{
	
	}
	
	
	
}
