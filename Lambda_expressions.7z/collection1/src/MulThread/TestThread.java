package MulThread;

import java.util.concurrent.ForkJoinPool;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TestThread {

	public static void main(String[] args) {
		Threadexample t1 = new Threadexample("Hello");
		Threadexample t2 = new Threadexample("World!!!");
		t1.start();
		t2.start();
		
		
		/*ForkJoinPool forkJoinPool = new ForkJoinPool(2);  
		  
	
		  
		forkJoinPool.submit(() ->  range(1, 1_000_000).parallel().filter(TestThread::isPrime).collect(Collectors.toList())).get(); 

	*/}
 public int isPrime(int n){
	 if(n%2==0){
		 return n;
		 
	 }
	 else return 0;
 }
 
 /*public static int range(int first,int last ){
	 for(int i=first;i<=last;i++){
		 System.out.println(i);
	 }
 }*/
}
