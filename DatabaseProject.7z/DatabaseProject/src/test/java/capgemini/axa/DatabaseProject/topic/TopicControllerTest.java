package capgemini.axa.DatabaseProject.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;



@RunWith(SpringRunner.class)
@WebMvcTest(value = TopicController.class, secure = false)
public class TopicControllerTest {
	
	@MockBean
	private TopicService topicService;
	@Test
	public void testListOfTopics(){
		 List<Topic> topic =Arrays.asList(new
				  Topic("Java", "Collection", "Arrays,linkedList"), new Topic(".Net",
							 "Iteration", "Different Iterating loops"), new Topic("Database", "sql",
							  "Basic sql queries"));
		 
		 //listMock =   Mockito.mock(Topic.class);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/students/Student1/courses/Course1").accept(
				MediaType.APPLICATION_JSON);
		//System.out.println(listMock);
		 
		
	}

}
