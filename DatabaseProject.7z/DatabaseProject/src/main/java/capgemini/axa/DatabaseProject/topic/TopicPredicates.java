package capgemini.axa.DatabaseProject.topic;

public class TopicPredicates {

}
