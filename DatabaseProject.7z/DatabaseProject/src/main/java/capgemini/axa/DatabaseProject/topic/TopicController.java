package capgemini.axa.DatabaseProject.topic;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TopicController {
	@Autowired
	private TopicService topicService;

	@GetMapping("/topics")
	public List<Topic> listOfTopics() {

		return topicService.getAllTopics();

	}

	@GetMapping("/topics/{id}") /////////////////// id is a variable
	public Optional<Topic> getTopicDetails(@PathVariable String id) { ///// id is a
															///// variable of
															///// url
		return topicService.getTopicById(id);

	}

	@PostMapping("/topics/add")
	public void addTopic(@RequestBody List<Topic> topic) {
		topicService.addNewTopic(topic);
	}
	
	/*@PutMapping("/topics/{id}")
	public void updateTopic(@RequestBody Topic topic,@PathVariable String id) {
		topicService.updateTopic(id, topic);
		
	}*/
	@PutMapping("/topics/{id}")
	public void updateTopic(@RequestBody Topic topic,@PathVariable String id) {
		topicService.updateTopic1(id,topic);
	}
	
	@DeleteMapping("/topics/{id}")
	public void deleteTopic(@PathVariable String id){
		 topicService.deleteTopic(id);
	}
	
	

}
