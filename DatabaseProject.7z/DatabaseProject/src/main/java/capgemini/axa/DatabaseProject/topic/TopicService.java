package capgemini.axa.DatabaseProject.topic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TopicService {
	@Autowired
	private TopicRepository topicrepository;
	/////////// Arrays is immutable
	
	 public List<Topic> topics = new ArrayList<>(Arrays.asList(new
	  Topic("Java", "Collection", "Arrays,linkedList"), new Topic(".Net",
	 "Iteration", "Different Iterating loops"), new Topic("Database", "sql",
	  "Basic sql queries")));
	 

	public List<Topic> getAllTopics() {
		List<Topic> topic = new ArrayList<>();
		topicrepository.findAll().forEach(topic::add);
		
		return topic;

	}

	public Optional<Topic> getTopicById(String id) {
		Optional<Topic> topic =topicrepository.findById(id);
		return topic;
		

	}

	public void addNewTopic(List<Topic> topic) {

		topicrepository.saveAll(topic);


	}

	public void updateTopic1(String id, Topic topic) {
		
		topicrepository.save(topic);

	}

	public void deleteTopic(String id) {
		
		//topicrepository.delete(id);
		

	}

}
