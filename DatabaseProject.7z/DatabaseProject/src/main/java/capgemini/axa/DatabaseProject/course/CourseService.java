package capgemini.axa.DatabaseProject.course;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import capgemini.axa.DatabaseProject.topic.Topic;

@Service
public class CourseService {

	@Autowired
	private CourseRepository courseRepository;
	Topic topic=new Topic();
	Course course = new DozerBeanMapper().map(topic, Course.class);

	public List<Course> getAllCourses() {
		List<Course> course = new ArrayList<>();

		courseRepository.findAll().forEach(course::add);
		

		return course;

	}

	public List<Course> searchByTopicId(String topicId) {

		return courseRepository.findByTopicId(topicId);
	}

	public void addCourse(Course course) {
		
		courseRepository.save(course);
		

	}

}
