package capgemini.axa.DatabaseProject.topic;


import org.springframework.data.repository.CrudRepository;
public interface TopicRepository extends CrudRepository<Topic, String> {

}
