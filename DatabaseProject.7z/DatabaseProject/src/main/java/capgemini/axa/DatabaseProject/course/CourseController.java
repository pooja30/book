package capgemini.axa.DatabaseProject.course;

import java.util.List;

import javax.ws.rs.Consumes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import capgemini.axa.DatabaseProject.topic.Topic;

@RestController
public class CourseController {

	@Autowired
	private CourseService courseService;

	@GetMapping("/courses")
	public List<Course> listOfCourse() {

		return courseService.getAllCourses();

	}

	@GetMapping("topics/{id}/courses")
	@Consumes("application/json")
	public List<Course> searchByTopicId(@PathVariable String id) {

		return courseService.searchByTopicId(id);

	}

	@PostMapping("/topics/{topicId}/courses")
	public void addCourse(@RequestBody Course course,@PathVariable String topicId) {
		course.setTopic(new Topic(topicId,"",""));
		courseService.addCourse(course);
	}

}
